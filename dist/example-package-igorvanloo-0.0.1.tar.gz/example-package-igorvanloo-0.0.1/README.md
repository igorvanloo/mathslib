# mathslib
 A compilation of mathematical functions and alogrithms I have used to solve problems on Project Euler
