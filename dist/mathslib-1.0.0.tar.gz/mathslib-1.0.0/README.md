# mathslib

 A compilation of Mathematical Functions and Algorithms I have made or come across.
 
 I have used most of these for [Project Euler](https://projecteuler.net/about)
 
 You can see their implementation on my website [ivl-projecteuler](https://www.ivl-projecteuler.com/)
